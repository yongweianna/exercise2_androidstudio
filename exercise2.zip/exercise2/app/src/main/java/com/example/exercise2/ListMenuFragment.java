package com.example.exercise2;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class ListMenuFragment extends Fragment {
    Context thisContext;
    // storing data into Array
    String[] users = new String[] { "Lim","Yong","Wei","Anna","Very","Cantik" };
    String[] location = new String[]{"here","there","that","this","sini","sana"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.activity_list_menu_fragment, container, false);

        // Binding Array to ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, users);

        ListView namelist = (ListView) view.findViewById(R.id.list);
        //binding the Array to display using listView
        namelist.setAdapter(adapter);
        thisContext = container.getContext();
        namelist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                FragmentManager fm = getActivity().getSupportFragmentManager();
                DetailsFragment txt = (DetailsFragment)fm.findFragmentById(R.id.detailFragConView);
                namelist.setSelector(android.R.color.holo_blue_dark);
                txt.change("Name: " + users[position], "Location : " + location[position]);
            }
        });

        return view;
    }
}